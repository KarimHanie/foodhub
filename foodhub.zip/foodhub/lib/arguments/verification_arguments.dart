class VerificationArguments {
  final String? email;
  VerificationArguments({required this.email});
}