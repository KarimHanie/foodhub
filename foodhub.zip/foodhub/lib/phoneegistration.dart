import 'package:flutter/material.dart';
class PhoneRegistration extends StatelessWidget {
  const PhoneRegistration({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
