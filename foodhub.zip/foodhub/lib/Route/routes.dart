class Routes{
 static const String welcomeScreen="welcomeScreen";
 static const String onBoard="onBoardScreen";
 static const String signUp="sinUp";
 static const String login="login";
 static const String resetPassword="reset_password";
 static const String phoneRegistration="phoneReg";
 static const String verificationCode="verification";

}