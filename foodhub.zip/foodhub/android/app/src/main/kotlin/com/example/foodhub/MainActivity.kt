package com.example.foodhub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
